function ConcentrationApp() {
  
}

var game = new ConcentrationApp();